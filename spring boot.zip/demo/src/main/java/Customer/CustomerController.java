package Customer;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class CustomerController {
    private customerRepository repository;

    public CustomerController(customerRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/customer")
    List<customer> all(){
        return repository.findAll();
    }

    @GetMapping("/customer/{id}")
    customer get(@PathVariable Long id){
        return repository.findById(id)
                .orElseThrow(()-> new customerNotFoundException(id));
    }
    @PostMapping("/customer")
    customer save(@RequestBody customer newCustomer){
        return this.repository.save(newCustomer);
    }
    @DeleteMapping("/customer/{id}")
    void delete(@PathVariable Long id){
       repository.deleteById(id);
    }

    @PutMapping("/customer/{id}")
    customer update(@PathVariable Long id, @RequestBody customer newcustomer){
        return repository.findById(id).map(customer -> {
            customer.setEmail(newcustomer.getEmail());
            customer.setName(newcustomer.getName());
            return customer;
        }).orElseGet(()->{
            newcustomer.setId(id);
            return repository.save(newcustomer);
        });
    }

}
