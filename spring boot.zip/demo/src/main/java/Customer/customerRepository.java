package Customer;

import org.springframework.data.jpa.repository.JpaRepository;

interface customerRepository extends JpaRepository<customer,Long> {

}
