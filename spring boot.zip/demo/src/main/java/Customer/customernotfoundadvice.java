package Customer;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@ControllerAdvice
public class customernotfoundadvice {
    @ResponseBody
            @ExceptionHandler(customerNotFoundException.class)
            @ResponseStatus(HttpStatus.NOT_FOUND)
    String customernotfoundhandler(customerNotFoundException ex){
        return ex.getMessage();

    }
}
