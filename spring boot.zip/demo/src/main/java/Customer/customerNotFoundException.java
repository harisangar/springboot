package Customer;

public class customerNotFoundException extends RuntimeException{
    public customerNotFoundException(Long id) {
        super(String.format("customer with id %s not found",id));
    }
}
